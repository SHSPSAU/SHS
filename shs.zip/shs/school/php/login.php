<?php include 'db.php';

if(isset($_POST['login']))
{
  $email=(isset($_POST['email']) ? $_POST['email']: '');
  $password=(isset($_POST['password']) ? $_POST['password']: '');

  $stmt = $con->prepare(
      "SELECT acc_email, acc_pword
    FROM accounts
    WHERE acc_email = ? AND acc_pword = ? AND acc_type = 'user1' AND acc_status = 'UNBLOCKED'
    LIMIT 1"
    );
  $stmt->bind_param("ss", $email, $password);
  $stmt->execute();
  $found = $stmt->fetch();

    if ( $found == true ) {
    session_start();
    $_SESSION['school'] = $email;
        echo '<script>
                window.location.href="../students.php";
            </script>';

      }else{
        $msg = "Incorrect User or User Bloked!";
      }
      echo '<script>
                window.location.href="../index.php";
                alert("'.$msg.'");
            </script>';
}