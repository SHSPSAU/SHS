<?php include 'db.php';
session_start();

$requirements=(isset($_POST['requirements']) ? $_POST['requirements']: '');

$email = $_SESSION['school'];

        mysqli_query($con,
        "UPDATE `details` SET `det_requirements`= '$requirements' WHERE `det_schl_email` = '$email'");

        echo '<script> 
            alert("Requirements has been updated!");
            window.location.href="../requirements.php";
        </script>';