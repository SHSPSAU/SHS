<?php include 'db.php';
session_start();

$contact=(isset($_POST['contact']) ? $_POST['contact']: '');

$email = $_SESSION['school'];

        mysqli_query($con,
        "UPDATE `details` SET `det_contact`= '$contact' WHERE `det_schl_email` = '$email'");

        echo '<script> 
            alert("Courses has been updated!");
            window.location.href="../contact.php";
        </script>';