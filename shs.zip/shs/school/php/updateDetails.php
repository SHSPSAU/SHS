<?php include 'db.php';
session_start();

$details=(isset($_POST['details']) ? $_POST['details']: '');

$email = $_SESSION['school'];

        mysqli_query($con,
        "UPDATE `details` SET `det_about`= '$details' WHERE `det_schl_email` = '$email'");

        echo '<script> 
            alert("Details has been updated!");
            window.location.href="../about.php";
        </script>';