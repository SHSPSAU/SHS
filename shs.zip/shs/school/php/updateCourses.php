<?php include 'db.php';
session_start();

$courses=(isset($_POST['courses']) ? $_POST['courses']: '');

$email = $_SESSION['school'];

        mysqli_query($con,
        "UPDATE `details` SET `det_courses`= '$courses' WHERE `det_schl_email` = '$email'");

        echo '<script> 
            alert("Courses has been updated!");
            window.location.href="../courses.php";
        </script>';