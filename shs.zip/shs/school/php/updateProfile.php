<?php include 'db.php';
session_start();

$schoolName=(isset($_POST['schoolName']) ? $_POST['schoolName']: '');
$address=(isset($_POST['address']) ? $_POST['address']: '');
$admin=(isset($_POST['admin']) ? $_POST['admin']: '');
$password=(isset($_POST['password']) ? $_POST['password']: '');
$password2=(isset($_POST['password2']) ? $_POST['password2']: '');


$email = $_SESSION['school'];
$r = mysqli_query($con,"SELECT * FROM `schools` WHERE `schl_email` = '$email'");
while($row = $r->fetch_assoc())
{
    $id = $row['schl_id'];
    $name = $row['schl_name'];
    $email = $row['schl_email'];
}

if($password == $password2){

    if($schoolName != NULL){
        mysqli_query($con,
        "UPDATE `schools` SET `schl_name` = '$schoolName' WHERE `schl_id` = '$id'");

        mysqli_query($con,
        "UPDATE `students` SET `stud_school` = '$schoolName' WHERE `stud_school` = '$name'");

        mysqli_query($con,
        "UPDATE `details` SET `det_schl_name`= '$schoolName' WHERE `det_schl_email` = '$email'");
    }

    if($address != NULL){
        mysqli_query($con,
        "UPDATE `schools` SET `schl_address` = '$address' WHERE `schl_id` = '$id'");
    }

    if($admin != NULL){
        mysqli_query($con,
        "UPDATE `schools` SET `schl_admin` = '$admin' WHERE `schl_id` = '$id'");
    }

    if($password != NULL){
        mysqli_query($con,
        "UPDATE `schools` SET `schl_pass` = '$password' WHERE `schl_id` = '$id'");

        mysqli_query($con,
        "UPDATE `accounts` SET `acc_pword` = '$password' WHERE `acc_email` = '$email'");
    }


        extract($_POST);
        $filename = basename($_FILES['UploadImage']['name'], PATHINFO_FILENAME);

    if($filename != NULL){

        $UploadedFileName=$_FILES['UploadImage']['name'];

        if($UploadedFileName!='')
        {
        $TargetPath='../images/logo/'.$UploadedFileName;

        if(move_uploaded_file($_FILES['UploadImage']['tmp_name'], $TargetPath)){

            mysqli_query($con,
            "UPDATE `schools` SET `schl_logo` = '$filename' WHERE `schl_email` = '$email'");
        }
        }
    }

        echo '<script> 
            alert("School details has been updated!");
            window.location.href="../students.php";
        </script>';

}else{
        echo '<script> 
            alert("Password did not match!"); 
            window.location.href="../profile.php";
        </script>';

}