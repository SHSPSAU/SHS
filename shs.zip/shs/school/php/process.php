<?php include 'db.php';


if(isset($_GET['viewreq']))
{
    $file = $_GET['viewreq'];

        echo '<script>
                window.location.href="../students/requirements/'.$file.'";
            </script>';
}


//pagka accept ng student kelangan ma update ung status ni student tapos ung date ng exam

if(isset($_GET['accept']))
{
    $id = $_GET['accept'];

        $result = mysqli_query($con,"SELECT * FROM `applicants` WHERE `stud_id` = '$id' ");
        while($row = $result->fetch_assoc())
        {
            $name = $row['stud_name'];
            $age = $row['stud_age'];
            $mail = $row['stud_mail'];
            $school = $row['stud_school'];
        

        mysqli_query($con,
        "INSERT INTO `accepted` (`school_name`, `accepted_stud_name`, `accepted_stud_age`, `accepted_stud_mail`, `status`)
                        VALUES (  '$school',         '$name',            '$age',               '$mail',            '4')");

        mysqli_query($con,
        "UPDATE `applicants` SET `status`= '1' WHERE `stud_id` = '$id'");

        mysqli_query($con,
        "UPDATE `student_applied_school` SET `app_status`= 'ACCEPTED' WHERE `stud_email` = '$mail' AND `schl_name` = '$school' ");

        $date = date('Y-m-d', strtotime('+3 month'));

        mysqli_query($con,
        "UPDATE `student_applied_school` SET `exam_date`= '$date' WHERE `stud_email` = '$mail' AND `schl_name` = '$school' ");
    
        }
        
        echo '<script>
                window.location.href="students.php";
            </script>';
}

if(isset($_GET['expire']))
{
    $StudMail = $_GET['expire'];

    $schoolMail = $_SESSION['school'];

    $result = mysqli_query($con,"SELECT * FROM `schools` WHERE `schl_email` = '$schoolMail' ");
    while($row = $result->fetch_assoc())
    {

        $school = $row['schl_name'];

    
        mysqli_query($con,
        "UPDATE `student_applied_school` SET `app_status`= 'EXPIRED' WHERE `stud_email` = '$StudMail' AND `schl_name` = '$school' ");

            
        mysqli_query($con,
        "UPDATE `accepted` SET `status`= '5' WHERE `accepted_stud_mail` = '$StudMail' AND `school_name` = '$school' ");
         


        // mysqli_query($con,
        // "DELETE FROM `accepted` WHERE `accepted_stud_mail` = '$StudMail' AND `school_name` = '$school' ");
    
    }

        echo '<script>
                window.location.href="accepted.php";
            </script>';
}

if(isset($_GET['done']))
{
    $StudMail = $_GET['done'];

    $schoolMail = $_SESSION['school'];

    $result = mysqli_query($con,"SELECT * FROM `schools` WHERE `schl_email` = '$schoolMail' ");
    while($row = $result->fetch_assoc())
    {

        $school = $row['schl_name'];

    
        mysqli_query($con,
        "UPDATE `student_applied_school` SET `app_status`= 'DONE' WHERE `stud_email` = '$StudMail' AND `schl_name` = '$school' ");

            
        mysqli_query($con,
        "UPDATE `accepted` SET `status`= '3' WHERE `accepted_stud_mail` = '$StudMail' AND `school_name` = '$school' ");
         


        // mysqli_query($con,
        // "DELETE FROM `accepted` WHERE `accepted_stud_mail` = '$StudMail' AND `school_name` = '$school' ");
    
    }

        echo '<script>
                window.location.href="accepted.php";
            </script>';
}


if(isset($_GET['undo']))
{
    $StudMail = $_GET['undo'];

    $result = mysqli_query($con,"SELECT * FROM `applicants` WHERE `stud_mail` = '$StudMail' ");
    while($row = $result->fetch_assoc())
    {
        $school = $row['stud_school'];
        $id = $row['stud_id'];

    mysqli_query($con,
    "DELETE FROM `accepted` WHERE `accepted_stud_mail` = '$StudMail' AND `school_name` = '$school' ");


    mysqli_query($con,
    "UPDATE `student_applied_school` SET `app_status`= 'N/A' WHERE `stud_email` = '$StudMail' AND `schl_name` = '$school' ");

    mysqli_query($con,
    "UPDATE `applicants` SET `status`= '0' WHERE `stud_id` = '$id'");

    mysqli_query($con,
    "UPDATE `student_applied_school` SET `exam_date`= 'N/A' WHERE `stud_email` = '$StudMail' AND `schl_name` = '$school' ");

    }


        echo '<script>
                window.location.href="students.php";
            </script>';
}


