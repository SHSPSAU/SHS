<?php session_start(); 
//it requires the user to login.
if( empty($_SESSION['school']))
{
	$msg = 'Please Login';
		echo '<script>
			    alert("'.$msg.'");
			    window.location.href = "index.php";
			</script>';
}
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Senior High School | STUDENTS</title>

    <link href="css/list.css" rel="stylesheet">
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/drpDown.js"></script>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
				<img src="images/LOGO.png" alt="" height="80px" alt="">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
				<a class="nav-link active" href="students.php">Students</a>
				</li>
                <li class="nav-item">
				<a class="nav-link" href="accepted.php">Accepted Applicants</a>
				</li>
                <li class="dropdown nav-item">
                <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown" role="button" aria-expanded="false">Profile <span class="caret"></span></a>
                <ul class="dropdown-menu navbar-dark bg-dark" role="menu">
                  <li><a class="nav-link" href="profile.php" style="color: #f3c811;">Update Profile</a></li>
                  <li><a class="nav-link" href="requirements.php" style="color: #f3c811;">Update Requirements</a></li>
                  <li><a class="nav-link" href="courses.php" style="color: #f3c811;">Update Courses</a></li>
                  <li><a class="nav-link" href="about.php" style="color: #f3c811;">Update Details</a></li>
                  <li><a class="nav-link" href="contact.php" style="color: #f3c811;">Update Contact</a></li>
                </ul>
                </li>
				<li class="nav-item">
				<a class="nav-link" href="php/logout.php">Log-out</a>
				</li>
			</ul>
			</div>
	</nav><br>

    <div class="container-fluid admin-content" id="master-list">
          <div class="panel panel-info" style="margin: 1em;">
              <div class="panel-heading">
                    <h3 class="panel-title" style="text-align: center;">List of Applicants
                    </h3>
              </div>
              <div class="panel-body">
        <table class="table table-hover table-fixed" style="text-align: center; vertical-align: middle;">

          <!--Table head-->
          <thead>
            <tr>
              <th style="text-align: center; vertical-align: middle;">Name</th>
              <th style="text-align: center; vertical-align: middle;">Age</th>
              <th style="text-align: center; vertical-align: middle;">Mail</th>
              <th style="text-align: center; vertical-align: middle;">School</th>
              <th style="text-align: center; vertical-align: middle;">Current School</th>
              <th style="text-align: center; vertical-align: middle;">Date & Time Applied</th>
              <th style="text-align: center; vertical-align: middle;">Requirements</th>
              <th style="text-align: center; vertical-align: middle;">Action</th>
            </tr>
          </thead>
          <!--Table head-->

          <!--Table body-->
          <?php include 'php/db.php';
          $schoolName = $_SESSION['school']; include 'php/process.php';
                                $r = mysqli_query($con,"SELECT * FROM `schools` WHERE `schl_email` = '$schoolName'");
                                while($row = $r->fetch_assoc())
                                {
                                    $school = $row['schl_name'];
                                }

                                $result = mysqli_query($con,"SELECT * FROM `applicants` WHERE `stud_school` = '$school' ORDER BY `stud_id` DESC");
                                while($row = $result->fetch_assoc())
                                {
                                    $status = $row['status'];
                                    if( $status == '0'){
          ?>
          <tbody>
            <tr>
              <td><?=$row['stud_name'] ?></td>
              <td><?=$row['stud_age'] ?></td>
              <td><?=$row['stud_mail'] ?></td>
              <td><?=$row['stud_school'] ?></td>
              <td><?=$row['stud_cur_school'] ?></td>
              <td><?=$row['date_applied'] ?></td>
              <td><a type="submit" class="btn btn-info" title="View Requirements" href="?view=<?=$row['stud_id'] ?>">View</i></a></td>
              <td><a type="submit" class="btn btn-info" title="Accept Application" href="?accept=<?=$row['stud_id'] ?>">Accept</i></a></td>
            </tr>
                            
          </tbody>
          <?php }else if( $status == '1'){ ?>
            <tbody>
            <tr bgcolor="#ADD8E6">
              <td><?=$row['stud_name'] ?></td>
              <td><?=$row['stud_age'] ?></td>
              <td><?=$row['stud_mail'] ?></td>
              <td><?=$row['stud_school'] ?></td>
              <td><?=$row['stud_cur_school'] ?></td>
              <td><?=$row['date_applied'] ?></td>
              <td><a type="submit" class="btn btn-info" title="View Requirements" href="?view=<?=$row['stud_id'] ?>">View</i></a></td>
              <td><a type="submit" class="btn btn-info" title="Accept Application" href="?undo=<?=$row['stud_mail'] ?>">Undo</i></a></td>
            </tr>
                            
          </tbody>


              
          <?php } } ?>
          <!--Table body-->

        </table>
        <!--Table-->
              </div>
          </div>
      </div>

            <?php
                    if(isset($_GET['view']))
                     {
                        $id = $_GET['view'];
                        $res = mysqli_query($con,"SELECT * FROM `applicants` WHERE `stud_id` = '$id'");
                        while($row = $res->fetch_assoc())
            {?>
<!-- School Modal -->
<div class="container">
    <div class="modal fade" id="reqModal" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title">Requirements<h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">

                <div class="container-fluid admin-content" id="master-list">
                    <div class="panel panel-info" style="margin: 1em;">
                        <div class="panel-heading">
                                <h3 class="panel-title" style="text-align: center;">List of Requirements
                                </h3>
                        </div>
                        <div class="panel-body">
                    <table class="table table-hover table-fixed">

                    <!--Table head-->
                        <thead>
                            <tr>
                            <th style="text-align: center; vertical-align: middle;">Name</th>
                            <th style="text-align: center; vertical-align: middle;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><?=$row['stud_f138'] ?></td>
                                <td><a type="submit" class="btn btn-info" title="View" target="_blank" href="?viewreq=<?=$row['stud_f138'] ?>">View</i></a></td>
                            </tr>
                            <tr>
                                <td><?=$row['stud_f137'] ?></td>
                                <td><a type="submit" class="btn btn-info" title="View" target="_blank" href="?viewreq=<?=$row['stud_f137'] ?>">View</i></a></td>
                            <tr>
                            <tr>
                                <td><?=$row['stud_moral'] ?></td>
                                <td><a type="submit" class="btn btn-info" title="View" target="_blank" href="?viewreq=<?=$row['stud_moral'] ?>">View</i></a></td>
                            <tr>
                            <tr>
                                <td><?=$row['stud_pic'] ?></td>
                                <td><a type="submit" class="btn btn-info" title="View" target="_blank" href="?viewreq=<?=$row['stud_pic'] ?>">View</i></a></td>
                            <tr>
                            <tr>
                                <td><?=$row['stud_psa'] ?></td>
                                <td><a type="submit" class="btn btn-info" title="View" target="_blank" href="?viewreq=<?=$row['stud_psa'] ?>">View</i></a></td>
                            <tr>
                            <?php
                                if($row['stud_cert'] != "N/A"){
                            ?>
                            <tr>
                                <td><?=$row['stud_cert'] ?></td>
                                <td><a type="submit" class="btn btn-info" title="View" target="_blank" href="?view=<?=$row['stud_cert'] ?>">View</i></a></td>
                            <tr>
                            <?php } ?>
                        </tbody>
                    </table>
                             
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
    </div>
</div>
<?php } }?>

          <script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
        history.go(1);
        };
    </script>

<script type="text/javascript">
    $(window).on('load',function(){
        $('#reqModal').modal('show');
    });
</script>
    
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>