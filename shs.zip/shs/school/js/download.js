$('a#someID').attr({target: '_blank', 
                    href  : 'http://localhost/shs/school/requirements/logo.png'});