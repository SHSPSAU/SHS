<?php session_start(); 
//it requires the user to login.
if( empty($_SESSION['school']))
{
	$msg = 'Please Login';
		echo '<script>
			    alert("'.$msg.'");
			    window.location.href = "index.php";
			</script>';
}
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Senior High School | PROFILE</title>
    
            <!-- Mobiscroll JS and CSS Includes -->
        <link rel="stylesheet" href="css/mobiscroll.javascript.lite.min.css">
        <script src="js/mobiscroll.javascript.lite.min.js"></script>
        
        <link rel="stylesheet" type="text/css" href="css/main.css">
        <link rel="stylesheet" type="text/css" href="css/util.css">

    <link href="css/list.css" rel="stylesheet">
    <script src="js/jquery-1.11.1.min.js"></script>
    <link href="css/drpDown.css" rel="stylesheet">
    <script src="js/drpDown.js"></script>

    

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
				<img src="images/LOGO.png" alt="" height="80px" alt="">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
				<a class="nav-link" href="students.php">Students</a>
				</li>
                <li class="nav-item">
				<a class="nav-link" href="accepted.php">Accepted Applicants</a>
				</li>
                <li class="dropdown nav-item">
                <a href="#" class="dropdown-toggle nav-link active" data-toggle="dropdown" role="button" aria-expanded="false">Profile <span class="caret"></span></a>
                <ul class="dropdown-menu navbar-dark bg-dark" role="menu">
                  <li><a class="nav-link" href="profile.php" style="color: #f3c811;">Update Profile</a></li>
                  <li><a class="nav-link active" href="requirements.php" style="color: #f3c811;">Update Requirements</a></li>
                  <li><a class="nav-link" href="courses.php" style="color: #f3c811;">Update Courses</a></li>
                  <li><a class="nav-link" href="about.php" style="color: #f3c811;">Update Details</a></li>
				  <li><a class="nav-link" href="contact.php" style="color: #f3c811;">Update Contact</a></li>
                </ul>
                </li>
				<li class="nav-item">
				<a class="nav-link" href="php/logout.php">Log-out</a>
				</li>
			</ul>
			</div>
	</nav>

    <div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-t-30 p-b-50">
				<form class="login100-form validate-form p-b-33 p-t-5 box effect7"  method="POST" action="php/updateRequirements.php">
						<div><span class="login100-form-title p-b-41">Update Requirements</span></div>
					<div mbsc-page>
						<div class="md-login-form" mbsc-form>
							<div class="md-logo micons icon-mbsc-logo"></div>
							<div class="mbsc-form-group-inset">
								<label>
                                    <textarea rows="20" cols="50" name="requirements" placeholder="Requirements"></textarea>
								</label>
							</div>
							<!-- <div class="mbsc-form-group-inset mbsc-padding mbsc-align-center">
								<a href="#" class="md-signup">Don't have an account yet? Sign up.</a>
								<br><br>
								<a href="#" class="md-login">Forgot password?</a>
							</div> -->
							<div class="mbsc-form-group-inset mbsc-padding">
								<button type="submit" class="mbsc-btn-block md-signup-btn" name="login">Submit</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	
	<script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
        history.go(1);
        };
    </script>

    <script>
		// Use the settings object to change the theme
		mobiscroll.settings = {
			theme: 'mobiscroll'
		};
		</script>
</body>
</html>