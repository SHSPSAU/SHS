<?php session_start(); 
//it requires the user to login.
if( empty($_SESSION['school']))
{
	$msg = 'Please Login';
		echo '<script>
			    alert("'.$msg.'");
			    window.location.href = "index.php";
			</script>';
}
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Senior High School | STUDENTS</title>

    <link href="css/list.css" rel="stylesheet">
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/drpDown.js"></script>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
				<img src="images/LOGO.png" alt="" height="80px" alt="">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
				<a class="nav-link" href="students.php">Students</a>
				</li>
                <li class="nav-item">
				<a class="nav-link active" href="accepted.php">Accepted Applicants</a>
				</li>
                <li class="dropdown nav-item">
                <a href="#" class="dropdown-toggle nav-link" data-toggle="dropdown" role="button" aria-expanded="false">Profile <span class="caret"></span></a>
                <ul class="dropdown-menu navbar-dark bg-dark" role="menu">
                  <li><a class="nav-link" href="profile.php" style="color: #f3c811;">Update Profile</a></li>
                  <li><a class="nav-link" href="requirements.php" style="color: #f3c811;">Update Requirements</a></li>
                  <li><a class="nav-link" href="courses.php" style="color: #f3c811;">Update Courses</a></li>
                  <li><a class="nav-link" href="about.php" style="color: #f3c811;">Update Details</a></li>
                  <li><a class="nav-link" href="contact.php" style="color: #f3c811;">Update Contact</a></li>
                </ul>
                </li>
				<li class="nav-item">
				<a class="nav-link" href="php/logout.php">Log-out</a>
				</li>
			</ul>
			</div>
	</nav><br>

    <div class="container-fluid admin-content" id="master-list">
          <div class="panel panel-info" style="margin: 1em;">
              <div class="panel-heading">
                    <h3 class="panel-title" style="text-align: center;">Accepted Applicants</h3>
              </div>
              <div class="panel-body">
        <table class="table table-hover table-fixed" style="text-align: center; vertical-align: middle;">

          <!--Table head-->
          <thead>
            <tr>
              <th style="text-align: center; vertical-align: middle;">Name</th>
              <th style="text-align: center; vertical-align: middle;">Age</th>
              <th style="text-align: center; vertical-align: middle;">Mail</th>
              <th style="text-align: center; vertical-align: middle;">Deadline</th>
              <th style="text-align: center; vertical-align: middle;">Action</th>
            </tr>
          </thead>
          <!--Table head-->

          <!--Table body-->
          <?php include 'php/db.php';
          $schoolName = $_SESSION['school']; include 'php/process.php';
                                $r = mysqli_query($con,"SELECT * FROM `schools` WHERE `schl_email` = '$schoolName'");
                                while($row = $r->fetch_assoc())
                                {
                                    $school = $row['schl_name'];
                                }

                                $result = mysqli_query($con,"SELECT * FROM `student_applied_school` WHERE `schl_name` = '$school' ");
                                while($row = $result->fetch_assoc())
                                {
                                  $deadline = $row['exam_date'];
                                }

                                $result = mysqli_query($con,"SELECT * FROM `accepted` WHERE `school_name` = '$school'");
                                while($row = $result->fetch_assoc())
                                { 
                                  $status = $row['status'];
                                  if( $status == '4'){ 
          ?>
          <tbody>
            <tr>
              <td><?=$row['accepted_stud_name'] ?></td>
              <td><?=$row['accepted_stud_age'] ?></td>
              <td><?=$row['accepted_stud_mail'] ?></td>
              <td><?=$deadline?></td>
              <td>
                <a type="submit" class="btn btn-danger" title="Expire Application" href="?expire=<?=$row['accepted_stud_mail'] ?>">Expire</i></a>
                <a type="submit" class="btn btn-success" title="Done" href="?done=<?=$row['accepted_stud_mail'] ?>">Done</i></a>
              </td>
            </tr>
          </tbody>
          <?php }else if( $status == '5'){ ?> <!-- expired -->
            <tbody>
            <tr bgcolor="#CD5C5C">
              <td><?=$row['accepted_stud_name'] ?></td>
              <td><?=$row['accepted_stud_age'] ?></td>
              <td><?=$row['accepted_stud_mail'] ?></td>
              <td><?=$deadline?></td>
              <td>EXPIRED</td>
            </tr>
          </tbody>
        
        <?php }else if ( $status == '3'){ ?> <!-- done -->
          <tbody>
            <tr bgcolor="#32CD32">
              <td><?=$row['accepted_stud_name'] ?></td>
              <td><?=$row['accepted_stud_age'] ?></td>
              <td><?=$row['accepted_stud_mail'] ?></td>
              <td><?=$deadline?></td>
              <td>DONE</td>
            </tr>
          </tbody>

      <?php } }?>
          <!--Table body-->

        </table>
        <!--Table-->
              </div>
          </div>
      </div>

      <script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
        history.go(1);
        };
    </script>
    
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>
</html>