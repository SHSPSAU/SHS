<?php include 'db.php';

$schoolName=(isset($_POST['schoolName']) ? $_POST['schoolName']: '');
$address=(isset($_POST['address']) ? $_POST['address']: '');
$email=(isset($_POST['email']) ? $_POST['email']: '');
$admin=(isset($_POST['admin']) ? $_POST['admin']: '');
$password=(isset($_POST['password']) ? $_POST['password']: '');
$password2=(isset($_POST['password2']) ? $_POST['password2']: '');
$type=(isset($_POST['type']) ? $_POST['type']: '');



if($password == $password2){

    mysqli_query($con,
    "INSERT INTO `schools` (`schl_name`, `schl_address`, `schl_email`, `schl_admin`, `schl_pass`, `schl_logo`, `schl_type`)
                    VALUES (  '$schoolName', '$address',     '$email',    '$admin',    '$password', 'logo',      '$type')");

    
    mysqli_query($con,
    "INSERT INTO `accounts` (`acc_name`, `acc_email`, `acc_pword`, `acc_type`, `acc_status`)
                    VALUES ( '$admin',    '$email',    '$password', 'user1',    'UNBLOCKED')");

    mysqli_query($con,
    "INSERT INTO `details` (`det_schl_name`, `det_schl_email`, `det_requirements`, `det_courses`, `det_contact`, `det_about`)
                    VALUES (  '$schoolName',    '$email',           '',              '',                '',           '')");



    extract($_POST);
    $filename = basename($_FILES['UploadImage']['name'], PATHINFO_FILENAME);

    $UploadedFileName=$_FILES['UploadImage']['name'];

    if($UploadedFileName!='')
    {
    $TargetPath='../images/logo/'.$UploadedFileName;

    if(move_uploaded_file($_FILES['UploadImage']['tmp_name'], $TargetPath)){

        mysqli_query($con,
        "UPDATE `schools` SET `schl_logo` = '$filename' WHERE `schl_name` = '$schoolName'");
    }
    }
        echo '<script> 
            alert("School has been added!"); 
            window.location.href="../admin.php";
        </script>';

}else{
        echo '<script> 
            alert("Password did not match!"); 
            window.location.href="../school.php";
        </script>';

}