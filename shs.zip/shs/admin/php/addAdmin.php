<?php include 'db.php';

$name=(isset($_POST['name']) ? $_POST['name']: '');
$email=(isset($_POST['email']) ? $_POST['email']: '');
$password=(isset($_POST['password']) ? $_POST['password']: '');
$password2=(isset($_POST['password2']) ? $_POST['password2']: '');



if($password == $password2){
    
    mysqli_query($con,
    "INSERT INTO `accounts` (`acc_name`,`acc_email`, `acc_pword`, `acc_type`)
                    VALUES (  '$name',   '$email',    '$password', 'ADMIN')");

        echo '<script> 
            alert("User has been added!"); 
            window.location.href="../admin.php";
        </script>';

}else{
        echo '<script> 
            alert("Password did not match!"); 
            window.location.href="../school.php";
        </script>';

}