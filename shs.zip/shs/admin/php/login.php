<?php include 'db.php';

if(isset($_POST['login']))
{
  $email=(isset($_POST['email']) ? $_POST['email']: '');
  $password=(isset($_POST['password']) ? $_POST['password']: '');

  $stmt = $con->prepare(
      "SELECT acc_email, acc_pword
    FROM accounts
    WHERE acc_email = ? AND acc_pword = ? AND acc_type = 'ADMIN'
    LIMIT 1"
    );
  $stmt->bind_param("ss", $email, $password);
  $stmt->execute();
  $found = $stmt->fetch();

    if ( $found == true ) {
    session_start();
    $_SESSION['admin'] = $email;
        echo '<script>
                window.location.href="../admin.php";
            </script>';

      }else{
        $msg = "Incorrect username or password.";
      }
      echo '<script>
                window.location.href="../index.php";
                alert("'.$msg.'");
            </script>';
}