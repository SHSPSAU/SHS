<?php include 'db.php';

if(isset($_GET['block']))
{
    $userEmail = $_GET['block'];
    
        mysqli_query($con,
        "UPDATE `accounts` SET `acc_status` = 'BLOCKED' WHERE `acc_email` = '$userEmail'");


        echo '<script>
                alert("User Blocked!");
                window.location.href="userList.php";
            </script>';
}

if(isset($_GET['unblock']))
{
    $userEmail = $_GET['unblock'];
    
        mysqli_query($con,
        "UPDATE `accounts` SET `acc_status` = 'UNBLOCKED' WHERE `acc_email` = '$userEmail'");


        echo '<script>
                alert("User Unblocked!");
                window.location.href="userList.php";
            </script>';
}


if(isset($_GET['del']))
{
    $schoolName = $_GET['del'];

    $result = mysqli_query($con,"SELECT * FROM `schools` WHERE `schl_name` = '$schoolName' ");
    while($row = $result->fetch_assoc())
    {

        $school = $row['schl_email'];

    
        mysqli_query($con,
        "DELETE FROM `accounts` WHERE `acc_email` = '$school' ");    
    
    }
    
    mysqli_query($con,
        "DELETE FROM `schools` WHERE `schl_name` = '$schoolName' ");





        echo '<script>
                alert("school Deleted!");
                window.location.href="admin.php";
            </script>';
}



