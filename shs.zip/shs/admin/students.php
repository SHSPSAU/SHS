<?php session_start(); 
//it requires the user to login.
if( empty($_SESSION['admin']))
{
	$msg = 'Please Login';
		echo '<script>
			    alert("'.$msg.'");
			    window.location.href = "index.php";
			</script>';
}
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Senior High School | ADMIN</title>

	<link href="css/list.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
				<img src="images/LOGO.png" alt="" height="80px">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
				<a class="nav-link" href="admin.php">Home
					</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="school.php">School</a>
				</li>
				<li class="nav-item">
				<a class="nav-link active" href="students.php">Student</a>
        </li>
        <li class="nav-item">
				<a class="nav-link" href="addUser.php">Add User</a>
				</li>
        <li class="nav-item">
				<a class="nav-link" href="userList.php">User List</a>
				</li>
        <li class="nav-item">
				<a class="nav-link" href="schoolList.php">Delete School</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="php/logout.php">Log-out</a>
				</li>
			</ul>
			</div>
    </nav><br>
    
    <div class="container-fluid admin-content" id="master-list">
          <div class="panel panel-info" style="margin: 1em;">
              <div class="panel-heading">
                    <h3 class="panel-title" style="text-align: center;">List of Students
                    </h3>
              </div>
              <div class="panel-body">
        <table class="table table-hover table-fixed" style="text-align: center; vertical-align: middle;">

          <!--Table head-->
          <thead>
            <tr>
              <th style="text-align: center; vertical-align: middle;">ID</th>
              <th style="text-align: center; vertical-align: middle;">Name</th>
              <th style="text-align: center; vertical-align: middle;">Age</th>
              <th style="text-align: center; vertical-align: middle;">Mail</th>
              <th style="text-align: center; vertical-align: middle;">Applied School</th>
              <th style="text-align: center; vertical-align: middle;">Current School</th>
            </tr>
          </thead>
          <!--Table head-->

          <!--Table body-->
          <?php include 'php/db.php'; include 'php/process.php';
                                $result = mysqli_query($con,"SELECT * FROM `students`");
                                while($row = $result->fetch_assoc())
                                {
          ?>
          <tbody>
            <tr>
              <td><?=$row['stud_id'] ?></td>
              <td><?=$row['stud_name'] ?></td>
              <td><?=$row['stud_age'] ?></td>
              <td><?=$row['stud_mail'] ?></td>
              <td><?=$row['stud_school'] ?></td>
              <td><?=$row['stud_cur_school'] ?></td>
            </tr>
          </tbody>
          <?php } ?>
          <!--Table body-->

        </table>
        <!--Table-->
      </div>


      <script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
        history.go(1);
        };
    </script>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>