<?php session_start(); 
//it requires the user to login.
if( empty($_SESSION['admin']))
{
	$msg = 'Please Login';
		echo '<script>
			    alert("'.$msg.'");
			    window.location.href = "index.php";
			</script>';
}
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Senior High School | SCHOOL</title>

        <!-- Mobiscroll JS and CSS Includes -->
        <link rel="stylesheet" href="css/mobiscroll.javascript.lite.min.css">
	    <script src="js/mobiscroll.javascript.lite.min.js"></script>
	
    <link rel="stylesheet" type="text/css" href="css/main.css">
    <link rel="stylesheet" type="text/css" href="css/util.css">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
				<img src="images/LOGO.png" alt="" height="80px">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
				<a class="nav-link" href="admin.php">Home
					</a>
				</li>
				<li class="nav-item">
				<a class="nav-link active" href="school.php">School</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="students.php">Student</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="addUser.php">Add User</a>
				</li>
        		<li class="nav-item">
				<a class="nav-link" href="userList.php">User List</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="schoolList.php">Delete School</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="php/logout.php">Log-out</a>
				</li>
			</ul>
			</div>
    </nav>
    
    <div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-t-30 p-b-50">
				<form class="login100-form validate-form p-b-33 p-t-5 box effect7"  method="POST" enctype="multipart/form-data" action="php/addSchool.php">
						<div><span class="login100-form-title p-b-41">Add School</span></div>
					<div mbsc-page>
						<div class="md-login-form" mbsc-form>
							<div class="md-logo micons icon-mbsc-logo"></div>
							<div class="mbsc-form-group-inset">
								<label>
									<input type="text" name="schoolName" placeholder="School Name" required minlength="4"/>
								</label>
								<label>
									<input name="address" type="text" placeholder="Address" required minlength="4"/>
                                </label>
                                <label>
									<input name="email" type="email" placeholder="Email"  required minlength="4"/>
                                </label>
                                <label>
									<input name="admin" type="text" placeholder="Administrator" required minlength="4"/>
                                </label>
								<label>
									<select name="type">
                                        <option value="PUBLIC">Public</option>
										<option value="PRIVATE">Private</option>
                                    </select>
                                </label>
                                <label>
									<input name="password" type="password" placeholder="Password" data-password-toggle="true" required minlength="4"/>
                                </label>
                                <label>
									<input name="password2" type="password" placeholder="Confirm Password" data-password-toggle="true" required minlength="4"/>
                                </label>
                                <label for="files">
									<input name="UploadImage" type="file" placeholder="Logo" required minlength="4"/>
								</label>
							</div>
							<!-- <div class="mbsc-form-group-inset mbsc-padding mbsc-align-center">
								<a href="#" class="md-signup">Don't have an account yet? Sign up.</a>
								<br><br>
								<a href="#" class="md-login">Forgot password?</a>
							</div> -->
							<div class="mbsc-form-group-inset mbsc-padding">
								<button type="submit" class="mbsc-btn-block md-signup-btn" name="login">Submit</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>


    <script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
        history.go(1);
        };
    </script>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script>
		// Use the settings object to change the theme
		mobiscroll.settings = {
			theme: 'mobiscroll'
		};
		</script>
</body>
</html>