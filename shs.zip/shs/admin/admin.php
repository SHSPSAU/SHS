<?php session_start(); 
//it requires the user to login.
if( empty($_SESSION['admin']))
{
	$msg = 'Please Login';
		echo '<script>
			    alert("'.$msg.'");
			    window.location.href = "index.php";
			</script>';
}
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Senior High School | ADMIN</title>

	<link href="css/list.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    

</head>

<body>
	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
				<img src="images/LOGO.png" alt="" height="80px">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
				<a class="nav-link active" href="admin.php">Home
					</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="school.php">School</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="students.php">Student</a>
                </li>
                <li class="nav-item">
				<a class="nav-link" href="addUser.php">Add User</a>
				</li>
                <li class="nav-item">
				<a class="nav-link" href="userList.php">User List</a>
				</li>
                <li class="nav-item">
				<a class="nav-link" href="schoolList.php">Delete School</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="php/logout.php">Log-out</a>
				</li>
			</ul>
			</div>
	</nav><br>


	<div class="container">
 
    <div id="products" class="row view-group">
    <?php include 'php/db.php'; include 'about.php';
            $result = mysqli_query($con,"SELECT * FROM `schools`");
            while($row = $result->fetch_array())
            {
        ?>
                <div class="item col-xs-4 col-lg-4">
                    <div class="thumbnail">
                        <div class="img-event" style="text-align: center">
                        <a class="md-signup open-school" href="?view=<?=$row['schl_name'] ?>">
                            <img class="group list-group-image img-fluid" src="images/logo/<?=$row['schl_logo']; ?>" alt="" width="50%" height="50%"/>
                        </a>
                        </div>
                        <div class="caption card-body">
                            <h4 class="group card-title inner grid-group-item-heading text-center">
                                <?=$row['schl_name']; ?></h4>
                            <h4 class="group inner grid-group-item-text text-center">
                                <?=$row['schl_address'];?>
                            </h4>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
    </div>


                
    
<!-- School Modal
<div class="container">
    <div class="modal fade" id="schoolModal" role="dialog">
    <div class="modal-dialog" style="min-width: 100%; margin: 0;">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title">School Name</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div style="text-align: center">
                    <h4 class="modal-title">ABOUT</h4>
                </div>
            
            </div>
            <div class="modal-footer">
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
    </div>
</div> -->

    <script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
        history.go(1);
        };
    </script>

    
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>