<?php
//it requires the user to login.
if( empty($_SESSION['student']))
{
	$msg = 'Please Login';
		echo '<script>
			    alert("'.$msg.'");
			    window.location.href = "index.php";
			</script>';
}

if(isset($_GET['view']))
{

    $Schoolname = $_GET['view'];

    include 'php/db.php';
    $result = mysqli_query($con,"SELECT * FROM `details` WHERE `det_schl_name` = '$Schoolname' ");
    while($row = $result->fetch_array())
    {
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Senior High School | ABOUT</title>

	<link href="css/list.css" rel="stylesheet">

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    

</head>

<body>

<!-- School Modal -->
<div class="container">
    <div class="modal fade" id="schoolModal" role="dialog">
    <div class="modal-dialog" style="min-width: 100%; margin: 0;">
        <div class="modal-content">
            <div class="modal-header">
            <h4 class="modal-title"><?=$Schoolname?></h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <div style="text-align: center">
                    <h4 class="modal-title">ABOUT</h4>
                    <div class="container">
                        </p><?=$row['det_about']?></p>
                    </div>
                </div><br><br>

                <div>
                    <div class="col-md-2" style="text-align: center; margin: 0 auto">
                        <h4 class="modal-title">Requirements</h4>
                        <div class="container">
                            </p><?=$row['det_requirements']?></p>
                        </div>
                    </div>
                    <div class="col-md-2" style="text-align: center; display: inline-block;">
                        <h4 class="modal-title">Courses</h4>
                        <div class="container">
                            </p><?=$row['det_courses']?></p>
                        </div>
                    </div>
                    <div class="col-md-2" style="text-align: center; float: right;">
                        <h4 class="modal-title">Contacts</h4>
                        <div class="container">
                            </p><?=$row['det_contact']?></p>
                        </div>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
            <a type="button" class="btn btn-default" href="apply.php?schoolName=<?=$row['det_schl_name'] ?>">Apply</a>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
    </div>
</div>


<script type="text/javascript">
    $(window).on('load',function(){
        $('#schoolModal').modal('show');
    });
</script>
	

    <script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
        history.go(1);
        };
    </script>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>

    <?php } }?>