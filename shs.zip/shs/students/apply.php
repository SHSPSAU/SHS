<!DOCTYPE html>

<?php session_start(); 
//it requires the user to login.
if( empty($_SESSION['student']))
{
	$msg = 'Please Login';
		echo '<script>
			    alert("'.$msg.'");
			    window.location.href = "index.php";
			</script>';
}
?>

<html lang="en">
<head>

	<title>Senior High School | LOGIN</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	
    <style>
        ::-webkit-scrollbar { 
                display: none; 
        }
    </style>

	<script src="js/jquery-1.11.1.min.js"></script>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Mobiscroll JS and CSS Includes -->
    <link rel="stylesheet" href="css/mobiscroll.javascript.lite.min.css">
	<script src="js/mobiscroll.javascript.lite.min.js"></script>
	
</head>
<body>

	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
				<img src="images/LOGO.png" alt="" height="80px">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
				<a class="nav-link active" href="school.php">Home
					</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="appliedSchool.php">Applied School</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="php/logout.php">Log-out</a>
				</li>
			</ul>
			</div>
	</nav>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-t-30 p-b-50">
				<form class="login100-form validate-form p-b-33 p-t-5 box effect7"  method="POST" enctype="multipart/form-data" action="php/apply.php">
						<div><span class="login100-form-title p-b-41">apply into school</span></div>
					<div mbsc-page>
						<div class="md-login-form" mbsc-form>
							<div class="md-logo micons icon-mbsc-logo"></div>
							<div class="mbsc-form-group-inset">
										<?php include 'php/db.php';
											$stuEmail = $_SESSION['student'];
											$schlName = $_GET['schoolName'];
                                            $result = mysqli_query($con,"SELECT * FROM `accounts` WHERE `acc_email` = '$stuEmail' ");
                                            while($row = $result->fetch_array())
                                            {
                                        ?>
								<label>
									<input type="text" name="fname" value="<?=$row['acc_name'];?>" required minlength="4" readonly/>
								</label>
								<label>
									<input type="number" name="age" value="<?=$row['acc_age'];?>" required minlength="2" readonly/>
								</label>
                                <label>
									<input type="email" name="email" value="<?=$row['acc_email'];?>" required minlength="4" readonly/>
								</label>
                                <label>
                                    <select name="schoolName">
                                        <option value="<?=$schlName?>"><?=$schlName ?></option>
                                        <?php }; ?>
                                    </select>
								</label>
                                <label>
									<input type="text" name="curSchool" placeholder="Current School" required minlength="4"/>
								</label>
								<label>
									<label for="imageUpload" class="btn btn-primary btn-block btn-outlined">Form 138</label>
									<input name="F138" type="file" id="imageUpload" accept="image/*" style="display: none" onchange="validateFileType()" placeholder="Form 138" required>
									<!-- <input id="fileType" name="UploadFile" type="file" required accept="image/*" onchange="validateFileType()" multiple/> -->
								</label>
								<label>
									<label for="imageUpload2" class="btn btn-primary btn-block btn-outlined">Form 137</label>
									<input name="F137" type="file" id="imageUpload2" accept="image/*" style="display: none" onchange="validateFileType()" placeholder="Form 137" required>
								</label>
								<label>
									<label for="imageUpload3" class="btn btn-primary btn-block btn-outlined">Certificate of Good moral character</label>
									<input name="goodMoral" type="file" id="imageUpload3" accept="image/*" style="display: none" onchange="validateFileType()" placeholder="Certificate of Good moral character" required>
								</label>
								<label>
									<label for="imageUpload4" class="btn btn-primary btn-block btn-outlined">2x2 picture</label>
									<input name="pic" type="file" id="imageUpload4" accept="image/*" style="display: none" onchange="validateFileType()" placeholder="2x2 picture" required>
								</label>
								<label>
									<label for="imageUpload5" class="btn btn-primary btn-block btn-outlined">PSA Birth Certificate</label>
									<input name="PSA" type="file" id="imageUpload5" accept="image/*" style="display: none" onchange="validateFileType()" placeholder="PSA Birth Certificate" required>
								</label>
								<?php     
										$Schoolname = $_GET['schoolName'];
										$result = mysqli_query($con,"SELECT * FROM `schools` WHERE `schl_name` = '$Schoolname' ");
										while($row = $result->fetch_array())
										{
											$type = $row['schl_type'];
										}
										if($type == "PRIVATE"){
									?>
								<label>
									<label for="imageUpload6" class="btn btn-primary btn-block btn-outlined">Certificate/Diploma</label>
									<input name="cert" type="file" id="imageUpload6" accept="image/*" style="display: none" onchange="validateFileType()" placeholder="certificate/diploma" required>
								</label>
										<?php } ?>
							</div>
							<div class="mbsc-form-group-inset mbsc-padding mbsc-btn-group-block">
								<button type="submit" class="mbsc-btn-block" name="login">Submit</button>
								<button class="mbsc-btn-danger" name="login" onclick="window.location.href='school.php' ">Cancel</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
	

	<script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
        history.go(1);
        };
    </script>
	
	<script>
		// Use the settings object to change the theme
		mobiscroll.settings = {
			theme: 'mobiscroll'
		};
	</script>

	<script type="text/javascript">
		function validateFileType(){
			var fileName = document.getElementById("imageUpload").value;
			var idxDot = fileName.lastIndexOf(".") + 1;
			var extFile = fileName.substr(idxDot, fileName.length).toLowerCase();
			if (extFile=="jpg" || extFile=="jpeg" || extFile=="png"){
				//TO DO
			}else{
				var r = confirm("Only jpg/jpeg and png files are allowed!");
				if (r == true){
					window.location.reload();
				}else{
					window.location.reload();
				}
			}   
		}
	</script>

	<script type="text/javascript">
		$("[type=file]").on("change", function(){
		// Name of file and placeholder
		var file = this.files[0].name;
		var dflt = $(this).attr("placeholder");
		if($(this).val()!=""){
			$(this).next().text(file);
		} else {
			$(this).next().text(dflt);
		}
		});
	</script>

</body>
</html>