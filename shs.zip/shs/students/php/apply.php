<?php include 'db.php';
session_start();

$fname=(isset($_POST['fname']) ? $_POST['fname']: '');
$age=(isset($_POST['age']) ? $_POST['age']: '');
$Semail=(isset($_POST['email']) ? $_POST['email']: '');
$schoolName=(isset($_POST['schoolName']) ? $_POST['schoolName']: '');
$curSchool=(isset($_POST['curSchool']) ? $_POST['curSchool']: '');



    $result = mysqli_query($con,"SELECT * FROM `schools` WHERE `schl_name` = '$schoolName' ");
    while($row = $result->fetch_array())
    {
        $address = $row['schl_address'];
        $email = $row['schl_email'];
    }



    mysqli_query($con,
    "INSERT INTO `student_applied_school` ( `stud_email`, `schl_name`, `schl_address`, `schl_email`, `app_status`, `exam_date`)
                                    VALUES ( '$Semail',      '$schoolName', '$address',    '$email',     'N/A',        'N/A')");


    mysqli_query($con,
    "INSERT INTO `students` (`stud_name`, `stud_age`, `stud_mail`, `stud_school`, `stud_cur_school` )
                    VALUES ( '$fname',      '$age',     '$Semail',  '$schoolName',    '$curSchool' )");

    $date_applied = date("Y-m-d h:i:s A");

    mysqli_query($con,
        "INSERT INTO `applicants` (`stud_name`, `stud_age`, `stud_mail`, `stud_school`, `stud_cur_school`, `stud_f138`, `stud_f137`, `stud_moral`, `stud_pic`, `stud_psa`, `stud_cert`, `date_applied`, `status`)
                        VALUES (    '$fname',      '$age',     '$Semail',  '$schoolName',    '$curSchool',     'N/A',         'N/A',     'N/A',           'N/A',    'N/A',       'N/A',  '$date_applied',  '0')");



    extract($_POST);
    $file1 = basename($_FILES['F138']['name'], PATHINFO_FILENAME);
    $file2 = basename($_FILES['F137']['name'], PATHINFO_FILENAME);
    $file3 = basename($_FILES['goodMoral']['name'], PATHINFO_FILENAME);
    $file4 = basename($_FILES['pic']['name'], PATHINFO_FILENAME);
    $file5 = basename($_FILES['PSA']['name'], PATHINFO_FILENAME);
    $file6 = basename($_FILES['cert']['name'], PATHINFO_FILENAME);


    $UploadedFileName=$_FILES['F138']['name'];

    if($UploadedFileName!='')
    {
    $TargetPath='../requirements/'.$UploadedFileName;

    if(move_uploaded_file($_FILES['F138']['tmp_name'], $TargetPath)){

        mysqli_query($con,
        "UPDATE `applicants` SET `stud_f138` = '$file1' WHERE `stud_name` = '$fname' AND `stud_school` = '$schoolName' ");
    }
    }

    $UploadedFileName2=$_FILES['F137']['name'];

    if($UploadedFileName2!='')
    {
    $TargetPath='../requirements/'.$UploadedFileName2;

    if(move_uploaded_file($_FILES['F137']['tmp_name'], $TargetPath)){

        mysqli_query($con,
        "UPDATE `applicants` SET `stud_f137` = '$file2' WHERE `stud_name` = '$fname' AND `stud_school` = '$schoolName' ");
    }
    }

    $UploadedFileName3=$_FILES['goodMoral']['name'];

    if($UploadedFileName3!='')
    {
    $TargetPath='../requirements/'.$UploadedFileName3;

    if(move_uploaded_file($_FILES['goodMoral']['tmp_name'], $TargetPath)){

        mysqli_query($con,
        "UPDATE `applicants` SET `stud_moral` = '$file3' WHERE `stud_name` = '$fname' AND `stud_school` = '$schoolName' ");
    }
    }


    $UploadedFileName4=$_FILES['pic']['name'];

    if($UploadedFileName4!='')
    {
    $TargetPath='../requirements/'.$UploadedFileName4;

    if(move_uploaded_file($_FILES['pic']['tmp_name'], $TargetPath)){

        mysqli_query($con,
        "UPDATE `applicants` SET `stud_pic` = '$file4' WHERE `stud_name` = '$fname' AND `stud_school` = '$schoolName' ");
    }
    }


    $UploadedFileName5=$_FILES['PSA']['name'];

    if($UploadedFileName5!='')
    {
    $TargetPath='../requirements/'.$UploadedFileName5;

    if(move_uploaded_file($_FILES['PSA']['tmp_name'], $TargetPath)){
        
        mysqli_query($con,
        "UPDATE `applicants` SET `stud_psa` = '$file5' WHERE `stud_name` = '$fname' AND `stud_school` = '$schoolName' ");
    }
    }


    $UploadedFileName6=$_FILES['cert']['name'];

    if($UploadedFileName6!='')
    {
    $TargetPath='../requirements/'.$UploadedFileName6;

    if(move_uploaded_file($_FILES['cert']['tmp_name'], $TargetPath)){


    mysqli_query($con,
        "UPDATE `applicants` SET `stud_cert` = '$file6' WHERE `stud_name` = '$fname' AND `stud_school` = '$schoolName' ");
    }
    }



// extract($_POST);

//     //$file_folder = "files/";  // folder to load files

//     $newFname = trim($fname);
//     $newSchoolName = trim($schoolName);

//     $zip         = new ZipArchive();          // Load zip library 
//     $zip_name    = "../requirements/" . $newFname . $newSchoolName . time() . ".zip";       // Zip name
    
//     $ZipName = $newFname . $newSchoolName . time() . ".zip";

//     if($zip->open($zip_name, ZipArchive::CREATE) !== TRUE) {
//         //Opening zip file to load files
//         $error .= "* Sorry ZIP creation failed at this time<br/>";
//     }

//     $files = $_FILES['UploadFile']; // current 'file' field posted from HTML page

//     if(is_array($files['tmp_name'])) {
//         // multi file form
//         foreach($files['tmp_name'] as $k => $value) {
//             if($value == '') { // not empty field
//                 continue;
//             }
//             $zip->addFromString($files['name'][$k], file_get_contents($value));
//         }
//     } elseif($files['tmp_name'] != '') { // not empty field
//         // single file form
//         $zip->addFromString($files['name'], file_get_contents($files['tmp_name']));
//     }
//     $zip->close();

//     mysqli_query($con,
//     "INSERT INTO `applicants` (`stud_name`, `stud_age`, `stud_mail`, `stud_school`, `stud_cur_school`, `stud_requirements`)
//                     VALUES ( '$fname',      '$age',     '$Semail',  '$schoolName',    '$curSchool',        '$ZipName')");

        echo '<script> 
            alert("Successfully applied!"); 
            window.location.href="../appliedSchool.php";
        </script>';
