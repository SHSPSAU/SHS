<?php include 'db.php';

$email=(isset($_POST['email']) ? $_POST['email']: '');
$age=(isset($_POST['age']) ? $_POST['age']: '');
$Fname=(isset($_POST['Fname']) ? $_POST['Fname']: '');
$password=(isset($_POST['password']) ? $_POST['password']: '');
$password2=(isset($_POST['password2']) ? $_POST['password2']: '');



if($password == $password2){
    
    mysqli_query($con,
    "INSERT INTO `accounts` (`acc_name`, `acc_email`, `acc_age`, `acc_pword`, `acc_type`, `acc_status` )
                    VALUES ( '$Fname',    '$email',    '$age',    '$password', 'user',     'UNBLOCKED' )");


        echo '<script> 
            alert("Account created you can now login!"); 
            window.location.href="../index.php";
        </script>';

}else{
        echo '<script> 
            alert("Password did not match!"); 
            window.location.href="../signUp.php";
        </script>';

}