<?php include 'db.php';
session_start();

$fname=(isset($_POST['fname']) ? $_POST['fname']: '');
$age=(isset($_POST['age']) ? $_POST['age']: '');
$Semail=(isset($_POST['email']) ? $_POST['email']: '');
$schoolName=(isset($_POST['schoolName']) ? $_POST['schoolName']: '');
$curSchool=(isset($_POST['curSchool']) ? $_POST['curSchool']: '');



    $result = mysqli_query($con,"SELECT * FROM `schools` WHERE `schl_name` = '$schoolName' ");
    while($row = $result->fetch_array())
    {
        $address = $row['schl_address'];
        $email = $row['schl_email'];
    }



    mysqli_query($con,
    "INSERT INTO `student_applied_school` ( `stud_email`, `schl_name`, `schl_address`, `schl_email`, `app_status`, `exam_date`)
                                    VALUES ( '$Semail',      '$schoolName', '$address',    '$email',     'N/A',        'N/A')");


    mysqli_query($con,
    "INSERT INTO `students` (`stud_name`, `stud_age`, `stud_mail`, `stud_school`, `stud_cur_school` )
                    VALUES ( '$fname',      '$age',     '$Semail',  '$schoolName',    '$curSchool' )");


    $zip = new ZipArchive();

    $zip_name = "../requirements/" . time() . ".zip";

    if($zip->open($zip_name, ZipArchive::CREATE) !== TRUE ){
        $error .= "* SORRY ZIP CREATION FAILED<br>";

    }

    extract($_POST);
    $filename = basename($_FILES['UploadFile']['name'], PATHINFO_FILENAME);

    $UploadedFileName=$_FILES['UploadFile']['name'];

    if($UploadedFileName!='')
    {
    $TargetPath='../requirements/'.$UploadedFileName;

    if(move_uploaded_file($_FILES['UploadFile']['tmp_name'], $TargetPath)){

    mysqli_query($con,
    "INSERT INTO `applicants` (`stud_name`, `stud_age`, `stud_mail`, `stud_school`, `stud_cur_school`, `stud_requirements`)
                    VALUES ( '$fname',      '$age',     '$Semail',  '$schoolName',    '$curSchool',        '$filename')");
    }
    }
        echo '<script> 
            alert("Successfully applied!"); 
            window.location.href="../appliedSchool.php";
        </script>';
