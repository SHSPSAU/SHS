<?php session_start(); 
//it requires the user to login.
if( empty($_SESSION['student']))
{
	$msg = 'Please Login';
		echo '<script>
			    alert("'.$msg.'");
			    window.location.href = "index.php";
			</script>';
}
?>
<!DOCTYPE html>
<html>
<head>

    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>Senior High School | APPLIED</title>

    <style>
        ::-webkit-scrollbar { 
                display: none; 
        }
    </style>

    <link href="css/list.css" rel="stylesheet">
    <link href="css/table.css" rel="stylesheet">
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/drpDown.js"></script>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
	<!-- Navigation -->
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
				<img src="images/LOGO.png" alt="" height="80px">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
				</button>
			<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item">
				<a class="nav-link" href="school.php">Home
					</a>
				</li>
				<li class="nav-item">
				<a class="nav-link active" href="appliedSchool.php">Applied School</a>
				</li>
				<li class="nav-item">
				<a class="nav-link" href="php/logout.php">Log-out</a>
				</li>
			</ul>
			</div>
	</nav><br>


    <div class="container-fluid admin-content table-responsive" id="master-list">
          <div class="panel panel-info" style="margin: 1em;">
              <div class="panel-heading">
                    <h3 class="panel-title" style="text-align: center;">Applied Schools
                    </h3>
              </div>
              <div class="panel-body">
        <table>

          <!--Table head-->
          <thead role="rowgroup">
            <tr role="row">
              <th style="text-align: center;">School Name</th>
              <th style="text-align: center;">School Address</th>
              <th style="text-align: center;">School Email</th>
              <th style="text-align: center;">Status</th>
              <th style="text-align: center;">Deadline</th>
            </tr>
          </thead>
          <!--Table head-->

          <!--Table body-->
          <?php include 'php/db.php';
          $email = $_SESSION['student'];
                                $result = mysqli_query($con,"SELECT * FROM `student_applied_school` WHERE `stud_email` = '$email' ORDER BY `app_id` DESC ");
                                while($row = $result->fetch_assoc())
                                {
          ?>
          <tbody role="rowgroup">
            <tr  role="row">
              <td style="text-align: center;"><?=$row['schl_name'] ?></td>
              <td style="text-align: center;"><?=$row['schl_address'] ?></td>
              <td style="text-align: center;"><?=$row['schl_email'] ?></td>
              <td style="text-align: center;"><?=$row['app_status'] ?></td>
              <td style="text-align: center;"><?=$row['exam_date'] ?></td>
            </tr>
          </tbody>
          <?php } ?>
          <!--Table body-->

        </table>
        <!--Table-->
              </div>
          </div>
      </div>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
        history.go(1);
        };
    </script>

</body>
</html>