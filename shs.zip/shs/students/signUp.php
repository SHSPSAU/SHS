<!DOCTYPE html>

<?php session_start(); 
//it requires the user to login.
if( !empty($_SESSION['student']))
{
		echo '<script>
			    window.location.href = "students.php";
			</script>';
}
?>

<html lang="en">
<head>
	<title>Senior High School | LOGIN</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	

    <style>
        ::-webkit-scrollbar { 
                display: none; 
        }
    </style>
	
    <!-- Mobiscroll JS and CSS Includes -->
    <link rel="stylesheet" href="css/mobiscroll.javascript.lite.min.css">
	<script src="js/mobiscroll.javascript.lite.min.js"></script>
	
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100 p-t-30 p-b-50">
				<form class="login100-form validate-form p-b-33 p-t-5 box effect7"  method="POST" action="php/create.php">
						<div><span class="login100-form-title p-b-41">Create Account</span></div>
						<div><span class="login100-form-title p-b-41">Senior High School</span></div>
						<div style="text-align: center"><img src="images/LOGO.png" height="100px" class="center"/></div>
					<div mbsc-page>
						<div class="md-login-form" mbsc-form>
							<div class="md-logo micons icon-mbsc-logo"></div>
							<div class="mbsc-form-group-inset">
								<label>
									<input type="text" name="Fname" placeholder="Full Name" required minlength="4" data-icon="ion-android-social-user"/>
								</label>
								<label>
									<input type="email" name="email" placeholder="Email" required minlength="4" data-icon="user4"/>
								</label>
								<label>
									<input type="number" name="age" placeholder="Age" required data-icon="ion-android-social-user" />
								</label>
								<label>
									<input name="password" type="password" placeholder="Password" data-password-toggle="true" required minlength="4" data-icon="lock2"/>
								</label>
                                <label>
									<input name="password2" type="password" placeholder="Confirm Password" data-password-toggle="true" required minlength="4" data-icon="lock2"/>
								</label>
							</div>
                            <div class="mbsc-form-group-inset mbsc-padding mbsc-align-center">
								<a href="index.php" class="md-signup">Already have an account? Sign in.</a>
							</div>
							<div class="mbsc-form-group-inset mbsc-padding">
								<button type="submit" class="mbsc-btn-block md-signup-btn" name="login">Sign Up</button>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>

	<script>
        history.pushState(null, null, location.href);
        window.onpopstate = function () {
        history.go(1);
        };
    </script>
	
	<script>
		// Use the settings object to change the theme
		mobiscroll.settings = {
			theme: 'mobiscroll'
		};
		</script>

</body>
</html>